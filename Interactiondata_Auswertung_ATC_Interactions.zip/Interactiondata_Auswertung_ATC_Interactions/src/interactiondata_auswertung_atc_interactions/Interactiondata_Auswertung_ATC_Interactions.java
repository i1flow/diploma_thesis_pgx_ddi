package interactiondata_auswertung_atc_interactions;

import ddi_high_memory.interactions.ComparaATC;
import ddi_high_memory.interactions.InteractionATC;
import ddi_high_memory.interactions.InteractionList;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Dieses Programm extrahiert aus der Quellen-Datei des Interaktions-Programms
 * die Interaktionen der gewünschten ATC-Codes Bei Angabe von #ZAHL werden alle
 * Interaktionen mit den ATC-Codes der Tiefe ZAHL extrahiert
 *
 * @author Wolfgang Kuch
 */
public class Interactiondata_Auswertung_ATC_Interactions {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException, IOException {
        System.out.print("Bitte Quelle angeben : ");
        Scanner sc = new Scanner(System.in);
        String eingabe = sc.nextLine();

        eingabe = "interaktions_paare_objects_new.data";

        ArrayList<InteractionList> interactionlists;
        interactionlists = loadInteractionLists(eingabe);

        String atc1;
        String atc2;

        System.out.println("Daten geladen");
        System.out.println();

        System.out.print("Ersten ATC-Code eingeben: ");
        atc1 = sc.nextLine();

        System.out.print("Zweiten ATC-Code eingeben: ");
        atc2 = sc.nextLine();

        extractData_triage(interactionlists, atc1, atc2);
    }

    /**
     *
     * @param datafile
     * @return
     * @throws IOException
     * @throws ClassNotFoundException
     */
    private static ArrayList<InteractionList> loadInteractionLists(String datafile) throws IOException, ClassNotFoundException {
        File f = new File(datafile);
        ObjectInputStream os = new ObjectInputStream(new FileInputStream(f));

        os.readLong();  //Patientenanzahl
        int len = os.readInt();

        ArrayList<InteractionList> list = new ArrayList<InteractionList>(len);
        for (int i = 0; i < len; i++) {
            InteractionList l = (InteractionList) os.readObject();
            l.getInteractions().sort(new ComparaATC());
            list.add(l);
        }

        os.close();

        return list;
    }

    /**
     *
     * @param interactionlists
     * @param atc1
     * @param atc2
     * @return
     * @throws IOException
     */
    private static boolean extractData_triage(ArrayList<InteractionList> interactionlists, String atc1, String atc2) throws IOException {
        if ((!atc1.matches("\\#\\d") && atc2.matches("\\#\\d")) || (atc1.matches("\\#\\d") && !atc2.matches("\\#\\d"))) {

            if (atc1.length() == 2) {
                extractData_groups(interactionlists, Integer.parseInt(atc1.substring(1, 2)), atc2);
            } else if (atc2.length() == 2) {
                extractData_groups(interactionlists, Integer.parseInt(atc2.substring(1, 2)), atc1);
            }

            return true;
        } else if (atc1.matches("\\#\\d") && atc2.matches("\\#\\d")) {
            if (atc1.length() != 2 && atc2.length() != 2) {
                return false;
            }
            System.err.println("Der Vergleich #ZAHL / #ZAHL wird nicht unterstützt");
            return false;
        }
        extractData(interactionlists, atc1, atc2);
        return true;
    }

    /**
     *
     * @param interactionlists
     */
    private static void extractData(ArrayList<InteractionList> interactionlists, String atc1, String atc2) throws IOException {

        BufferedWriter bw = new BufferedWriter(new FileWriter("output.txt"));
        ArrayList<InteractionATC> results = new ArrayList<InteractionATC>();
        for (InteractionList list : interactionlists) {
            results.clear();
            newInteractionList(list);
            bw.write(list.getName());
            bw.newLine();

            for (InteractionATC a : list.getInteractions()) {
                if (a.getCount_without_doubles() == 0) {
                    continue;
                }
                if (!a.atcs.isEmpty()) {
                    for (InteractionATC atcs : a.atcs) {
                        if (atcs.getCount_without_doubles() == 0) {
                            continue;
                        }
                        if (atcs.atc1.startsWith(atc1)) {
                            if (atcs.atc2.startsWith(atc2)) {
                                results.add(atcs);
                            }
                        } else if (atcs.atc1.startsWith(atc2)) {
                            if (atcs.atc2.startsWith(atc1)) {
                                results.add(atcs);
                            }
                        }
                    }
                } else if (a.atc1.startsWith(atc1)) {
                    if (a.atc2.startsWith(atc2)) {
                        results.add(a);
                    }
                } else if (a.atc1.startsWith(atc2)) {
                    if (a.atc2.startsWith(atc1)) {
                        results.add(a);

                    }
                }
            }

            results.sort(new ComparaATC());

            for (InteractionATC atc : results) {
                bw.write(atc.atc1 + ":" + atc.atc2 + ";" + atc.getCount_without_doubles());
                bw.newLine();
            }
        }

        bw.close();

        System.out.println("Ergebnisse in der Datei \"output.txt\" erfolgreich gespeichert");
    }

    /**
     * Die mit sternchen N06A* angabe kommt hier rein
     *
     * @param interactionlists
     * @param atc1
     * @param atc2
     * @throws IOException
     */
    private static void extractData_groups(ArrayList<InteractionList> interactionlists, int atc1, String atc2) throws IOException {
        ArrayList<InteractionATC> results = new ArrayList<InteractionATC>();
        BufferedWriter bw = new BufferedWriter(new FileWriter("output.txt"));

        for (InteractionList list : interactionlists) {
            results.clear();
            newInteractionList(list);
            bw.write(list.getName());
            bw.newLine();

            for (InteractionATC atc : list.getInteractions()) {
                if (atc.atc1.startsWith(atc2)) {
                    String atcgroup = atc.atc2.substring(0, atc1);
                    InteractionATC newatc = new InteractionATC(atcgroup, atc.atc1);
                    newatc.count_without_doubles = atc.getCount_without_doubles();

                    int index = results.indexOf(newatc);
                    if (index != -1) {
                        long count = results.get(index).getCount_without_doubles();
                        newatc.count_without_doubles += count;
                        results.remove(index);  //Alten Eintrag löschen
                        results.add(newatc);    //Neuen hinzufügen
                    } else {
                        results.add(newatc);
                    }
                } else if (atc.atc2.startsWith(atc2)) {
                    String atcgroup = atc.atc1.substring(0, atc1);
                    InteractionATC newatc = new InteractionATC(atcgroup, atc.atc2);
                    newatc.count_without_doubles = atc.getCount_without_doubles();

                    int index = results.indexOf(newatc);
                    if (index != -1) {
                        long count = results.get(index).getCount_without_doubles();
                        newatc.count_without_doubles += count;
                        results.remove(index);  //Alten Eintrag löschen
                        results.add(newatc);    //Neuen hinzufügen
                    } else {
                        results.add(newatc);
                    }
                }
            }

            results.sort(new ComparaATC());

            for (InteractionATC atc : results) {
                bw.write(atc.atc1 + ":" + atc.atc2 + ";" + atc.getCount_without_doubles());
                bw.newLine();
            }
        }

        bw.close();
    }
    
    /**
     * neue Liste, welche die ATCs kürzer als 7 in die Einzelnen ATC-Codes
     * aufteilt
     *
     * @param l
     */
    public static void newInteractionList(InteractionList l) {
        ArrayList<InteractionATC> deletelist = new ArrayList<InteractionATC>();
        ArrayList<InteractionATC> addlist = new ArrayList<InteractionATC>();

        for (InteractionATC atc : l.getInteractions()) {
            int i = 0;
            int j = 0;
            if (atc.atcgeneral) {
                if (!(atc.atcs == null)) {
                    if (!atc.atcs.isEmpty()) {
                        for (InteractionATC a : atc.atcs) {
                            i += a.count;
                            j += a.count_without_doubles;
                            addlist.add(a);
                        }
                        if (atc.count != i) {
                            if (atc.count_without_doubles != j) {
                                System.err.println("Nicht gleich!");
                                throw new RuntimeException();
                            }
                        }
                        deletelist.add(atc);

                    } else {
                        deletelist.add(atc);
                    }
                }
            }
        }
        l.getInteractions().removeAll(deletelist);
        l.interactions.addAll(addlist);
    }
}
