/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ddi_high_memory.interactions;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Wolfi
 */
public class InteractionList implements Serializable {

    private String name;
    public ArrayList<InteractionATC> interactions = null;

    public InteractionList(String name, ArrayList<InteractionATC> list) {
        this.name = name;
        this.interactions = list;
    }

    public InteractionList(InteractionList list) {
        this.name = list.name;
        this.interactions = new ArrayList<InteractionATC>(list.interactions.size());
        if (this.interactions != null) {
            for (InteractionATC atc : list.interactions) {
                this.interactions.add(new InteractionATC(atc));
            }
        }

    }

    public String getName() {
        return name;
    }

    public ArrayList<InteractionATC> getInteractions() {
        return interactions;
    }

    public void setInteractions(ArrayList<InteractionATC> interactions) {
        this.interactions = interactions;
    }

    private void writeObject(java.io.ObjectOutputStream out) throws IOException {
        out.writeUTF(name);
        out.writeLong(interactions.size());
        for (InteractionATC atc : interactions) {
            out.writeObject(atc);
        }
    }

    private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException {
        this.name = in.readUTF();
        long anz = in.readLong();
        interactions = new ArrayList<InteractionATC>();

        for (long i = 0; i < anz; i++) {
            interactions.add((InteractionATC) in.readObject());
        }
    }

}
