/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ddi_high_memory.interactions;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author Wolfi
 */
public class Patient implements Serializable {
    private long pers_id;
    public ArrayList<Receipt> receipts = new ArrayList<Receipt>();

    public Patient(long pers_id) {
        this.pers_id = pers_id;
    }

    public Patient() {
    }

    public long getPers_id() {
        return pers_id;
    }

    public ArrayList<Receipt> getReceipts() {
        return receipts;
    }
    
    public void addReceipt(Receipt r) {
        this.receipts.add(r);
    }
    
    public void sortlist() {
        Collections.sort(receipts, new Compara());
    }
    
    private void writeObject(java.io.ObjectOutputStream out) throws IOException {
        out.writeInt((int) this.pers_id);
        out.writeInt(this.receipts.size());
        for(Receipt r : this.receipts) {
            out.writeUTF(r.getAtc());
            out.writeLong(r.getEindat());
            out.writeDouble(r.getDdd());
            out.writeLong(r.getVoanz());
        }
    }

    private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException {
        this.pers_id = in.readInt();
        int anz_r = in.readInt();
        this.receipts = new ArrayList<Receipt>();
        for(int i = 0; i < anz_r; i++) {
            Receipt receipt = new Receipt();
            receipt.setAtc(in.readUTF());
            receipt.setEindat(in.readLong());
            receipt.setDdd(in.readDouble());
            receipt.setVoanz(in.readLong());
            
            this.receipts.add(receipt);
        }
    }

    @Override
    public String toString() {
        return "Patienten-ID: " + this.pers_id + " mit " + this.receipts.size() + " Medikamente";
    }
}
