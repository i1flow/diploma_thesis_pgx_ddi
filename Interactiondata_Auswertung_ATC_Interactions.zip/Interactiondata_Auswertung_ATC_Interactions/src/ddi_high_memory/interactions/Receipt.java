/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ddi_high_memory.interactions;

import java.util.Calendar;
import java.util.Objects;

/**
 *
 * @author Wolfi
 */
public class Receipt implements Comparable<Receipt> {

    public String atc;
    public long eindat;
    public double ddd;
    public long voanz;
    public long ted;

    public String getAtc() {
        return atc;
    }

    public void setAtc(String atc) {
        this.atc = atc;
    }

    public long getEindat() {
        return eindat;
    }

    public void setEindat(long eindat) {
        this.eindat = eindat / 86400000;
        
    }

    public double getDdd() {
        return ddd;
    }

    public void setDdd(double ddd) {
        this.ddd = ddd;
    }

    public long getVoanz() {
        return voanz;
    }

    public void setVoanz(long voanz) {
        this.voanz = voanz;
        this.ted = ((long) Math.ceil(this.ddd * this.voanz));
    }

    public long getTed() {
        return ted;
    }

    public void setTed(long ted) {
        this.ted = ted;
    }   

    @Override
    public String toString() {
        return "Receipt: " + atc + "   Datum: " + eindat + " : " + ddd + " : " + voanz;
    }

    

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 31 * hash + Objects.hashCode(this.atc);
        hash = 31 * hash + (int) (this.eindat ^ (this.eindat >>> 32));
        hash = 31 * hash + (int) (Double.doubleToLongBits(this.ddd) ^ (Double.doubleToLongBits(this.ddd) >>> 32));
        hash = 31 * hash + (int) (this.voanz ^ (this.voanz >>> 32));
        hash = 31 * hash + (int) (this.ted ^ (this.ted >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Receipt other = (Receipt) obj;
        if ((this.atc == null) ? (other.atc != null) : !this.atc.equals(other.atc)) {
            return false;
        }
        if (this.eindat != other.eindat) {
            return false;
        }
        if (Double.doubleToLongBits(this.ddd) != Double.doubleToLongBits(other.ddd)) {
            return false;
        }
        if (this.voanz != other.voanz) {
            return false;
        }
        if (this.ted != other.ted) {
            return false;
        }
        return true;
    }

    @Override
    public int compareTo(Receipt o) {
        return Long.compare(this.eindat, o.getEindat());
    }

    

}
