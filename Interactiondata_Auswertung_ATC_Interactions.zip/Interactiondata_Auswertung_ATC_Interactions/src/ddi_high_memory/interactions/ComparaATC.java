/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ddi_high_memory.interactions;

import java.util.Comparator;

/**
 *
 * @author Wolfi
 */
public class ComparaATC implements Comparator<InteractionATC>{

    @Override
    public int compare(InteractionATC o1, InteractionATC o2) {
        return Long.compare(o2.count_without_doubles, o1.count_without_doubles);
    }
    
}
