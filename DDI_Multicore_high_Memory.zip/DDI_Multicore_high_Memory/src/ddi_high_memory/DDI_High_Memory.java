package ddi_high_memory;

import ddi_high_memory.interactions.InteractionATC;
import ddi_high_memory.interactions.InteractionList;
import ddi_high_memory.interactions.Receipt;
import ddi_high_memory.interactions.Patient;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;
import static java.lang.Thread.sleep;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Diploma Thesis Drug Drug Interactions
 * @author Wolfgang Kuch
 */
public class DDI_High_Memory {

    public final static boolean LOW_MEMORY = false;
    public static ArrayList<InteractionList> interactlist = new ArrayList<InteractionList>();
    public static ArrayList<ArrayList<InteractionList>> interact = new ArrayList<ArrayList<InteractionList>>();

    /**
     * @param args 0: Liste mit den Rezepten, 1-n: Interaktionslisten, auf
     * welche geprüft werden soll
     * @throws java.lang.ClassNotFoundException
     * @throws java.sql.SQLException
     * @throws java.io.FileNotFoundException
     * @throws java.text.ParseException
     * @throws java.lang.InterruptedException
     *
     */
    public static void main(String[] args) throws ClassNotFoundException, SQLException, FileNotFoundException, ParseException, IOException, InterruptedException {
        int cores = (int) (Runtime.getRuntime().availableProcessors());
        //cores = 2;
        System.out.println("Anzahl Threads: " + cores);

        System.out.println("Patientenliste: " + args[0]);
        System.out.println("Interaktionsliste(n): ");
        for (int i = 1; i < args.length; i++) {
            System.out.println("    " + args[i]);
        }

        File f = new File(args[0]);
        BufferedReader br = new BufferedReader(new FileReader(f));

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

        String line = br.readLine(); //Erste Zeile verwerfen (Tabellenüberschriften)
        String[] splitline = null;

        long pat_id = -1;

        Patient p = null;
        Receipt r = null;

        /**
         * Interaktionslisten aus den Dateien laden
         */
        for (int i = 1; i < args.length; i++) {
            ArrayList<InteractionATC> a = getInteractionATCfromFile(new File(args[i]));
            interactlist.add(new InteractionList(args[i], a));
        }

        /**
         * Jeder Thread erhält eigene Interaktionslisten
         */
        for (int i = 0; i < cores; i++) {
            ArrayList<InteractionList> temp = copyArrayList(interactlist);
            interact.add(temp);
        }
        System.out.println("Interaktionslisten geladen");

        long anzahlzeilen = f.length() / 35;
        f = null;

        System.out.println("Geschätzte Zeilen in der Patienten-Datei: " + anzahlzeilen);   //Schätzung der Anzahl der Zeilen, die im File enthalten sind

        /**
         * Erzeugung und Initialisierung der Interaktions-Threads
         */
        Interaction_Thread[] workingthreads = new Interaction_Thread[cores];
        System.out.println("Initialisiere Auswertungs-Threads");

        ConcurrentLinkedQueue<Patient> patientqueue = new ConcurrentLinkedQueue<Patient>();

        for (int i = 0; i < cores; i++) {
            workingthreads[i] = new Interaction_Thread(patientqueue, interact.get(i));
            workingthreads[i].setDaemon(true);
            workingthreads[i].setPriority(Thread.MAX_PRIORITY - 1);
            workingthreads[i].start();
        }

        Runtime.getRuntime().gc();

        /**
         * Auswertungs-Schleife
         */
        System.out.println("Auswertung wird begonnen");

        long patientenanzahl = 0;
        while ((line = br.readLine()) != null) {

            //Patient laden
            splitline = line.split(";");
            Long id = Long.parseLong(splitline[0]);
            //Wenn ein neuer Patient geladen wurde, wird der Alte zur Auswertung in die Queue gegeben
            if (pat_id != id) {
                if (pat_id != -1) {
                    p.sortlist();
                    patientqueue.add(p);
                    patientenanzahl++;
                    if (LOW_MEMORY) {
                        if (Runtime.getRuntime().freeMemory() < 500000000) {
                            Thread.sleep(10000);
                        }
                    }
                }
                pat_id = id;
                p = new Patient(pat_id);
            }

            //Rezepte laden
            r = new Receipt();

            //ATC
            r.setAtc(splitline[1].trim());
            if (splitline[1].length() != 7) {
                System.err.println(splitline[1]);
            }

            //DATUM
            r.setEindat(format.parse(splitline[2]).getTime());

            //DDD UND TED
            try {
                r.setDdd(Double.parseDouble(splitline[3]));
            } catch (NumberFormatException e) {
                r.setDdd(30);       //Bei leerem TED wird standardmäßig 30 Tage angenommen
            } catch (ArrayIndexOutOfBoundsException e) {
                r.setDdd(30);
            }
            try {
                r.setVoanz(Long.parseLong(splitline[4]));
            } catch (NumberFormatException e) {
                r.setVoanz(1);      //Standard bei leerer Packungsanzahl = 1
            } catch (ArrayIndexOutOfBoundsException e) {
                r.setVoanz(1);
            }
            p.addReceipt(r);
        }
        //Letzten Patienten auch in Queue hinzufügen
        p.sortlist();
        patientqueue.add(p);
        patientenanzahl++;

        br.close();

        /**
         * Warten, dass alle Patienten ausgewertet werden
         */
        System.out.println("Alle Daten in Arbeitsspeicher geladen. Bitte warten");
        while (true) {
            System.out.println("Noch " + patientqueue.size() + " Patienten übrig");
            if (patientqueue.isEmpty()) {
                System.out.println("Auswertung beendet. Bitte warten");
                sleep(60000);
                for (Interaction_Thread t : workingthreads) {
                    t.interrupt();
                }

                break;
            }
            sleep(60000);
        }

        System.out.println("Interaktions-Daten werden erstellt");

        try {
            //interactlist wird einfach bearbeitet
            for (int i = 0; i < interact.size(); i++) {  //i = Nummer der Threads 
                for (int j = 0; j < interact.get(i).size(); j++) { //j = Welche InteraktionsListe wird gezählt?
                    ArrayList<InteractionATC> l = interact.get(i).get(j).getInteractions();
                    for (int k = 0; k < l.size(); k++) {  //k = Einzelnen Interaktionen in der Liste durchgehen
                        InteractionATC iatc = interactlist.get(j).getInteractions().get(k); //Diese Interaktion wird jetzt bearbeitet
                        iatc.addCountDoubles(l.get(k).getCount_without_doubles());
                        iatc.addCount(l.get(k).getCount());

                        if (iatc.atcs == null && l.get(k).atcs != null) {
                            System.err.println(iatc.toString());
                            System.err.println(l.get(k).toString());
                            System.err.println(l.get(k).atcs.toString());

                        }
                        if (l.get(k).atcs != null) {
                            if (!l.get(k).atcs.isEmpty()) {
                                //Unterliste der InteractionATCs, wenn ATC-Code kleiner 7 zusammenzählen
                                for (Iterator it = l.get(k).atcs.iterator(); it.hasNext();) {
                                    InteractionATC atc = (InteractionATC) it.next();    //ATC-Code von der Unterliste
                                    //Kann man es hinzufügen, oder ist es schon in der neuen Liste vorhanden (dann addieren)
                                    if (!iatc.atcs.add(atc)) {
                                        //Nach dem schon vorhandenen suchen
                                        for (Iterator it2 = iatc.atcs.iterator(); it2.hasNext();) {
                                            InteractionATC atc2 = (InteractionATC) it2.next();
                                            if (atc2.equals(atc)) {
                                                atc2.addCount(atc.count);
                                                atc2.addCountDoubles(atc.count_without_doubles);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (NullPointerException ex) {
            System.err.println(ex.toString());
            System.err.println();
            System.err.println(ex.getMessage());
            throw new NullPointerException();
        }

        System.out.println("Interaktionspaar-Objekte werden gespeichert");
        File file = new File("interaktions_paare_objects_french_sameday.data");
        ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(file));

        os.writeLong(patientenanzahl);

        os.writeInt(interactlist.size());
        for (int i = 0; i < interactlist.size(); i++) {
            os.writeObject(interactlist.get(i));
        }

        os.close();

        System.out.println("Interaktionspaar-Objekte gespeichert");
        System.out.println("Programm beendet");
    }

    /**
     * Läd die Interaktionen, welcher sich in dem File befinden und gibt eine
     * ArrayList mit InteractionATC-Objekten zurück. Doppelte Interaktionen
     * werden ignoriert.
     *
     * @param file Datei, in welcher sich die Interaktionen befinden
     * @return ArrayList mit InteractionATC-Objekten
     * @throws FileNotFoundException
     * @throws IOException
     */
    private static ArrayList<InteractionATC> getInteractionATCfromFile(File file) throws FileNotFoundException, IOException {
        Collection<InteractionATC> interactions = new HashSet<InteractionATC>();

        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);

        String str;
        String[] atcs;
        while ((str = br.readLine()) != null) {
            atcs = str.split(";");

            //Interaktionen mit sich selber ausschließen
            if (atcs[0].equals(atcs[1])) {
                continue;
            }

            //Wenn ATC Code ungültig (die franz. Interaktionsliste enthält dies)
            if (atcs[0].equals("as") || atcs[1].equals("as")) {
                continue;
            }

            /**
             * Aussortieren und Zusammenfassen der Interaktionen
             */
            for (InteractionATC atc : interactions) {
                if (atcs[0].length() == 7 && atcs[1].length() == 7) {
                    break;
                }

                if (atcs[0].length() < 7 && atcs[1].length() == 7) {
                    if (atc.atc1.contains(atcs[0])) {
                        if (atc.atc2.equals(atcs[1])) {
                            interactions.remove(atc);
                            break;
                        }
                    } else if (atc.atc2.contains(atcs[0])) {
                        if (atc.atc1.equals(atcs[1])) {
                            interactions.remove(atc);
                            break;
                        }
                    }
                } else if (atcs[0].length() == 7 && atcs[1].length() < 7) {
                    if (atc.atc1.contains(atcs[1])) {
                        if (atc.atc2.equals(atcs[0])) {
                            interactions.remove(atc);
                            break;
                        }
                    } else if (atc.atc2.contains(atcs[1])) {
                        if (atc.atc1.equals(atcs[0])) {
                            interactions.remove(atc);
                            break;
                        }
                    }
                } else if (atcs[0].length() < 7 && atcs[1].length() < 7) {
                    if (atc.atc1.contains(atcs[0])) {
                        if (atc.atc2.contains(atcs[1])) {
                            interactions.remove(atc);
                            break;
                        }
                    } else if (atc.atc2.contains(atcs[0])) {
                        if (atc.atc1.contains(atcs[1])) {
                            interactions.remove(atc);
                            break;
                        }
                    }

                }
            }
            if (atcs[0].length() == 7 || atcs[1].length() == 7) {
                boolean ausstieg = false;
                for (InteractionATC a : interactions) {
                    if ((atcs[0].contains(a.atc1))) {
                        if (atcs[1].contains(a.atc2)) {
                            ausstieg = true;
                            break;
                        }
                    } else if (atcs[1].contains(a.atc1)) {
                        if (atcs[0].contains(a.atc2)) {
                            ausstieg = true;
                            break;
                        }
                    }
                }

                if (ausstieg) {
                    continue;
                }
            }

            InteractionATC a = new InteractionATC(atcs[0], atcs[1]);
            if (atcs[0].length() < 7 || atcs[1].length() < 7) {
                a.setAtcgeneral(true);
            }
            interactions.add(a);

        }

        br.close();
        ArrayList<InteractionATC> a = new ArrayList<InteractionATC>(interactions);
        a.trimToSize();

        return a;
    }

    public static ArrayList<InteractionList> copyArrayList(ArrayList<InteractionList> list) {
        ArrayList<InteractionList> newlist = new ArrayList<InteractionList>(list.size());

        for (InteractionList l : list) {
            newlist.add(new InteractionList(l));
        }

        return newlist;
    }
}
