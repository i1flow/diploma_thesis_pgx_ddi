package ddi_high_memory;

import ddi_high_memory.interactions.InteractionATC;
import ddi_high_memory.interactions.InteractionList;
import ddi_high_memory.interactions.Receipt;
import ddi_high_memory.interactions.Patient;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Diploma Thesis Drug Drug Interactions
 * Working-Thread
 * @author Wolfgang Kuch
 */
public class Interaction_Thread extends Thread {

    private final ArrayList<InteractionList> interact;
    private final ConcurrentLinkedQueue<Patient> patients;

    public Interaction_Thread(ConcurrentLinkedQueue<Patient> patients, ArrayList<InteractionList> interact) {
        this.patients = patients;
        this.interact = interact;
    }

    @Override
    public void run() {
        Thread.currentThread().setName("Interaction_Thread");

        while (!this.isInterrupted()) {
            //Patient aus Queue laden
            Patient p = patients.poll();

            /**
             * Wenn keine vorhanden, nochmal versuchen und dann 1 sek. warten
             */
            while (p == null) {
                p = patients.poll();

                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ex) {
                }
            }

            ArrayList<Receipt> list = p.receipts;

            for (InteractionList inter : this.interact) {
                HashSet<InteractionATC> doubles = new HashSet<InteractionATC>(30); //mehrfache Interaktionen werden aussortiert

                for (int i = 0; i < list.size(); i++) {
                    Receipt r1 = list.get(i);
                    if (i < (list.size() - 1)) {
                        for (int j = i + 1; j < list.size(); j++) {

                            Receipt r2 = list.get(j);
                            if(r1.atc.equals(r2.atc)) {
                                continue;
                            }

                            //Wenn das Datum vom ersten Rezept + die Reichweite größer ist, als das Datum des zweiten Rezeptes
                            if ((r1.eindat + r1.ted) >= r2.eindat) {
                            //if (r1.eindat == r2.eindat) {
                                if (!doubles.add(new InteractionATC(r1.atc, r2.atc))) { //Wenn diese Interaktion schon überprüft worden ist
                                    checkInteraction(r1, r2, inter.interactions);
                                } else {
                                    checkInteraction(r1, r2, inter.interactions, true);
                                }
                            }
                        }
                    }
                }
            }
        }

        System.err.println(Thread.currentThread().getName() + " beendet");

    }

    /**
     *
     * @param r1
     * @param r2
     * @param interact
     * @return
     */
    private boolean checkInteraction(Receipt r1, Receipt r2, ArrayList<InteractionATC> interact) {
        for (InteractionATC interaction : interact) {
            if (r1.atc.startsWith(interaction.atc1)) {
                if (r2.atc.startsWith(interaction.atc2)) {
                    if (interaction.atcgeneral) {
                        InteractionATC a = new InteractionATC(r1.atc, r2.atc);
                        a.count++;
                        boolean yes = interaction.atcs.add(a);
                        if (!yes) {
                            for (Iterator<InteractionATC> it = interaction.atcs.iterator(); it.hasNext();) {
                                InteractionATC at = it.next();
                                if (at.equals(a)) {
                                    at.addCount(a.count);
                                }
                            }
                        }
                    }
                    interaction.count++;
                    return true;
                }
            } else if (r1.atc.startsWith(interaction.atc2)) {
                if (r2.atc.startsWith(interaction.atc1)) {
                    if (interaction.atcgeneral) {
                        InteractionATC a = new InteractionATC(r1.atc, r2.atc);
                        a.count++;
                        boolean yes = interaction.atcs.add(a);
                        if (!yes) {
                            for (Iterator<InteractionATC> it = interaction.atcs.iterator(); it.hasNext();) {
                                InteractionATC at = it.next();
                                if (at.equals(a)) {
                                    at.addCount(a.count);
                                }
                            }

                        }
                    }
                    interaction.count++;
                    return true;
                }
            }
        }

        return false;
    }

    /**
     *
     * @param r1 Rezept 1
     * @param r2 Rezept 2
     * @param interact Interaktionsliste
     * @param dummy
     * @return true, wenn eine Interaktion gefunden wurde
     */
    private boolean checkInteraction(Receipt r1, Receipt r2, ArrayList<InteractionATC> interact, boolean dummy) {
        for (InteractionATC interaction : interact) {
            if (r1.atc.startsWith(interaction.atc1)) {
                if (r2.atc.startsWith(interaction.atc2)) {
                    if (interaction.atcgeneral) {
                        InteractionATC a = new InteractionATC(r1.atc, r2.atc);
                        a.count++;
                        a.count_without_doubles++;
                        boolean yes = interaction.atcs.add(a);
                        if (!yes) {
                            for (Iterator<InteractionATC> it = interaction.atcs.iterator(); it.hasNext();) {
                                InteractionATC at = it.next();
                                if (at.equals(a)) {
                                    at.addCount(a.count);
                                    at.addCountDoubles(a.count_without_doubles);
                                }
                            }
                        }
                        
                    }
                    interaction.count++;
                    interaction.count_without_doubles++;
                    return true;
                }
            } else if (r1.atc.startsWith(interaction.atc2)) {
                if (r2.atc.startsWith(interaction.atc1)) {
                    if (interaction.atcgeneral) {
                        InteractionATC a = new InteractionATC(r1.atc, r2.atc);
                        a.count++;
                        a.count_without_doubles++;
                        boolean yes = interaction.atcs.add(a);
                        if (!yes) {
                            for (Iterator<InteractionATC> it = interaction.atcs.iterator(); it.hasNext();) {
                                InteractionATC at = it.next();
                                if (at.equals(a)) {
                                    at.addCount(a.count);
                                    at.addCountDoubles(a.count_without_doubles);
                                }
                            }

                        }
                    }
                    interaction.count++;
                    interaction.count_without_doubles++;
                    return true;
                }
            }
        }

        return false;

    }
}
