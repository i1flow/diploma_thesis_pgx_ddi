package ddi_high_memory.interactions;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Iterator;

/**
 *
 * @author Wolfi
 */
public class InteractionATC implements Comparable, Serializable {

    public String atc1;
    public String atc2;
    public long count;
    public long count_without_doubles;
    public HashSet<InteractionATC> atcs = null;
    public boolean atcgeneral = false;

    public InteractionATC(String atc1, String atc2) {
        this.atc1 = atc1;
        this.atc2 = atc2;
        this.count = 0;
        this.count_without_doubles = 0;
    }

    public InteractionATC() {
    }

    public InteractionATC(InteractionATC atc) {
        this.atc1 = atc.atc1;
        this.atc2 = atc.atc2;
        this.atcgeneral = atc.atcgeneral;
        this.count = atc.count;
        this.count_without_doubles = atc.count_without_doubles;
        if (atc.atcs != null) {
            this.atcs = new HashSet<InteractionATC>();
            if (!atc.atcs.isEmpty()) {
                for(Iterator it = atc.atcs.iterator(); it.hasNext();) {
                    InteractionATC a = (InteractionATC) it.next();
                    this.atcs.add(new InteractionATC(a));
                }
            }
        }
    }

    public String getAtc1() {
        return atc1;
    }

    public void setAtc1(String atc1) {
        this.atc1 = atc1;
    }

    public String getAtc2() {
        return atc2;
    }

    public void setAtc2(String atc2) {
        this.atc2 = atc2;
    }

    public long getCount() {
        return count;
    }

    public void addCount() {
        this.count++;
    }

    public void addCount(long value) {
        this.count += value;
    }

    public void addCountDoubles() {
        this.count_without_doubles++;
    }

    public void addCountDoubles(long value) {
        this.count_without_doubles += value;
    }

    public long getCount_without_doubles() {
        return count_without_doubles;
    }

    public void setAtcgeneral(boolean atcgeneral) {
        this.atcgeneral = atcgeneral;
        this.atcs = new HashSet<InteractionATC>(10);

    }

    @Override
    public int compareTo(Object o) {
        InteractionATC atc = (InteractionATC) o;

        return Long.compare(this.count, atc.count);
        //return new Integer(count).compareTo(atc.count);
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + (this.atc1 != null ? this.atc1.hashCode() : 0) + (this.atc2 != null ? this.atc2.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final InteractionATC other = (InteractionATC) obj;

        if (!this.atc1.equals(other.atc1)) {
            if (!this.atc1.equals(other.atc2)) {
                return false;
            }
        }
        if (!this.atc2.equals(other.atc2)) {
            if (!this.atc2.equals(other.atc1)) {
                return false;
            }
        }

        return true;
    }

    @Override
    public String toString() {
        return "InteractionATC{" + "atc1=" + atc1 + ", atc2=" + atc2 + ", count=" + count + ", count_without_doubles=" + count_without_doubles + '}';
    }

    private void writeObject(java.io.ObjectOutputStream out) throws IOException {
        out.writeUTF(this.atc1);
        out.writeUTF(this.atc2);
        out.writeLong(this.count);
        out.writeLong(this.count_without_doubles);
        if (this.atcs == null) {
            out.writeInt(0);
        } else if (this.atcs.isEmpty()) {
            out.writeInt(0);
        } else {
            out.writeInt(this.atcs.size());
            for (InteractionATC atc : this.atcs) {
                out.writeObject(atc);
            }
        }
        out.writeBoolean(this.atcgeneral);
    }

    private void readObject(java.io.ObjectInputStream in) throws IOException, ClassNotFoundException {
        this.atc1 = in.readUTF();
        this.atc2 = in.readUTF();
        this.count = in.readLong();
        this.count_without_doubles = in.readLong();
        int anz = in.readInt();
        this.atcs = new HashSet<InteractionATC>(anz);
        for (int i = 0; i < anz; i++) {
            this.atcs.add((InteractionATC) in.readObject());
        }
        this.atcgeneral = in.readBoolean();
    }
}
