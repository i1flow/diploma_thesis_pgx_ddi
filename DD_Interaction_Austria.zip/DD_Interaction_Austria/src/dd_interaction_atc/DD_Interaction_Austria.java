package dd_interaction_atc;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Erzeugt aus der SQl-Datei die
 * @author Wolfgang Kuch
 */
public class DD_Interaction_Austria {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        File f = new File("autCodexInteract.sql");
        BufferedReader br = new BufferedReader(new FileReader(f));

        File fw = new File("interaction_austria_heavy.csv");
        BufferedWriter bw = new BufferedWriter(new FileWriter(fw));

        String str = null;
        String atc1 = null;
        String atc2 = null;

        while ((str = br.readLine()) != null) {
            //Vorderes Zeichen weg
            int anfang = str.indexOf("'");
            int ende = str.lastIndexOf("'");
            str = str.substring(anfang, ende);

            //System.out.println(str);
            String[] split = str.split(",");

            atc1 = split[0];
            atc2 = split[1];

            //Nur schwere Interaktionen laden
            if (split.length > 2) {
                String strength = split[2];
                strength = strength.substring(2, strength.length());
                if (!strength.equals("S")) {
                    continue;
                }
            }

            atc1 = atc1.substring(1, atc1.length() - 1);
            atc2 = atc2.substring(2, atc2.length() - 1);

            bw.write(atc1, 0, atc1.length());
            bw.write(";", 0, 1);
            bw.write(atc2, 0, atc2.length());
            bw.newLine();

        }
        bw.close();
        br.close();
        
        //Alle
        f = new File("autCodexInteract.sql");
        br = new BufferedReader(new FileReader(f));
        
        fw = new File("interaction_austria.csv");
        bw = new BufferedWriter(new FileWriter(fw));

        str = null;
        atc1 = null;
        atc2 = null;

        while ((str = br.readLine()) != null) {
            //Vorderes Zeichen weg
            int anfang = str.indexOf("'");
            int ende = str.lastIndexOf("'");
            str = str.substring(anfang, ende);

            //System.out.println(str);
            String[] split = str.split(",");

            atc1 = split[0];
            atc2 = split[1];

            atc1 = atc1.substring(1, atc1.length() - 1);
            atc2 = atc2.substring(2, atc2.length() - 1);

            bw.write(atc1, 0, atc1.length());
            bw.write(";", 0, 1);
            bw.write(atc2, 0, atc2.length());
            bw.newLine();

        }
        
        br.close();
        bw.close();
    }

}
