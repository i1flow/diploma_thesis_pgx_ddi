package ddi_high_memory.interactions;

import java.util.Comparator;

/**
 *
 * @author Wolfi
 */
public class Compara implements Comparator<Receipt> {

    @Override
    public int compare(Receipt o1, Receipt o2) {
        if (o1.eindat < o2.eindat) {
            return -1;
        } else if (o1.eindat == o2.eindat) {
            return 0;
        } else {
            return 1;
        }
    }

}
