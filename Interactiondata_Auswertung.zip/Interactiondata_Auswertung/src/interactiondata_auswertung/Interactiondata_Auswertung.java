package interactiondata_auswertung;

import ddi_high_memory.interactions.ComparaATC;
import ddi_high_memory.interactions.InteractionATC;
import ddi_high_memory.interactions.InteractionList;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Wertet die Daten des DDI-Interaktionsprogrammes aus
 * @author Wolfgang Kuch
 */
public class Interactiondata_Auswertung {

    /**
     * @param args the command line arguments
     */
    private static final String FILE_WITHOUT_DOUBLES = "interactionlist_without_doubles.txt";
    private static final String FILE_WITH_DOUBLES = "interactionlist_with_doubles.txt";

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        ArrayList<InteractionList> list = loadInteractionLists("interaktions_paare_objects_new.data");

        System.setOut(new PrintStream(new File("out.txt")));

        ArrayList<InteractionList> l1 = new ArrayList<InteractionList>(list.size() + 100);
        for (InteractionList l : list) {
            l1.add(new InteractionList(l));
        }

        for (InteractionList l : l1) {
            ArrayList<InteractionATC> deletelist = new ArrayList<InteractionATC>();
            ArrayList<InteractionATC> addlist = new ArrayList<InteractionATC>();
            for (InteractionATC atc : l.getInteractions()) {
                int i = 0;
                int j = 0;
                if (!(atc.atcs == null)) {
                    if (!atc.atcs.isEmpty()) {
                        for (InteractionATC a : atc.atcs) {
                            i += a.count;
                            j += a.count_without_doubles;
                            addlist.add(a);

                        }
                        if (atc.count != i) {
                            if (atc.count_without_doubles != j) {

                            }
                            System.err.println("Nicht gleich!");
                        }
                        deletelist.add(atc);

                    }
                }
            }
            l.getInteractions().removeAll(deletelist);
            l.interactions.addAll(addlist);
        }

        for (InteractionList li : l1) {
            HashSet<String> a = new HashSet<String>(1000);
            int i = 0; //Anzahl der Interaktionspaare
            for (InteractionATC atc : li.getInteractions()) {
                i++;
                a.add(atc.atc1);
                a.add(atc.atc2);
            }

            System.err.println(li.getName());
            System.err.println("   Anzahl der verschiedenen ATC-Codes: " + a.size());
            System.err.println("   Anzahl der verschiedenen Interaktionspaare: " + i);
        }

        getInteractions_without_doubles(list);
        getInteractions_with_doubles(list);

        getSummary(list);

        mostInteractionATCs_withoutdoubles(list);
        mostInteractionATCs_withdoubles(list);

        mostfalsedescribedmedis_without_doubles(list);
        mostfalsedescribedmedis_with_doubles(list);

        mostfalsedescribedmedis_without_doubles_third_stage(list);
        mostfalsedescribedmedis_with_doubles_third_stage(list);

        all_mostfalsedescribedmedis_without_doubles_third_stage(list);
        all_mostInteractionATCs_withoutdoubles(list);
        all_mostfalsedescribedmedis_without_doubles(list);

        all_three_getInteractions_without_doubles(list);

        onlyantidepressiva(list);
        onlyantidepressivamedis(list);

    }

    private static ArrayList<InteractionList> loadInteractionLists(String datafile) throws IOException, ClassNotFoundException {
        File f = new File(datafile);
        ObjectInputStream os = new ObjectInputStream(new FileInputStream(f));

        long patientenanzahl = os.readLong();
        System.err.println("Patientenanzahl: " + patientenanzahl);
        int len = os.readInt();

        ArrayList<InteractionList> list = new ArrayList<InteractionList>(len);
        for (int i = 0; i < len; i++) {
            InteractionList l = (InteractionList) os.readObject();
            l.getInteractions().sort(new ComparaATC());
            list.add(l);
        }

        os.close();

        return list;
    }

    /**
     *
     * @param list
     * @throws IOException
     */
    private static void getInteractions_without_doubles(ArrayList<InteractionList> list) throws IOException {
        File f = new File(FILE_WITHOUT_DOUBLES);
        BufferedWriter bw = new BufferedWriter(new FileWriter(f));

        for (InteractionList l : list) {
            bw.write(l.getName());
            bw.newLine();
            for (InteractionATC atc : l.getInteractions()) {
                bw.write(atc.getAtc1() + ":" + atc.getAtc2() + ";" + atc.getCount_without_doubles());
                bw.newLine();
            }
        }

        bw.close();
    }

    /**
     *
     * @param list
     * @throws IOException
     */
    private static void getInteractions_with_doubles(ArrayList<InteractionList> list) throws IOException {
        File f = new File(FILE_WITH_DOUBLES);
        BufferedWriter bw = new BufferedWriter(new FileWriter(f));

        for (InteractionList l : list) {
            bw.write(l.getName());
            bw.newLine();
            for (InteractionATC atc : l.getInteractions()) {
                bw.write(atc.getAtc1() + ":" + atc.getAtc2() + ";" + atc.getCount());
                bw.newLine();
            }
        }

        bw.close();
    }

    /**
     *
     * @param list
     */
    private static void getSummary(ArrayList<InteractionList> list) {
        long alerts = 0;

        System.out.println("Interactionlist without doubles");
        for (InteractionList l : list) {
            alerts = 0;
            System.out.print(l.getName() + ";");
            for (InteractionATC atc : l.getInteractions()) {
                alerts += atc.getCount_without_doubles();
            }
            System.out.println(alerts);
        }

        System.out.println("Interactionlist with doubles");
        for (InteractionList l : list) {
            alerts = 0;
            System.out.print(l.getName() + ";");
            for (InteractionATC atc : l.getInteractions()) {
                alerts += atc.getCount();
            }
            System.out.println(alerts);
        }
    }

    /**
     *
     * @param list
     * @throws IOException
     */
    private static void mostInteractionATCs_withoutdoubles(ArrayList<InteractionList> list) throws IOException {
        File f = new File("mostInteractionATCs_without_doubles.txt");
        BufferedWriter bw = new BufferedWriter(new FileWriter(f));
        for (InteractionList l : list) {
            bw.write(l.getName());
            bw.newLine();

            newInteractionList(l);
            ArrayList<InteractionATC> alist = l.getInteractions();
            alist.sort(new ComparaATC());
            for (int i = 0; i < alist.size(); i++) {

                bw.write(alist.get(i).getAtc1() + ":" + alist.get(i).getAtc2() + ";" + alist.get(i).getCount_without_doubles());
                bw.newLine();

            }
        }
        bw.close();
    }

    /**
     *
     * @param list
     * @throws IOException
     */
    private static void mostInteractionATCs_withdoubles(ArrayList<InteractionList> list) throws IOException {
        File f = new File("mostInteractionATCs_with_doubles.txt");
        BufferedWriter bw = new BufferedWriter(new FileWriter(f));
        for (InteractionList l : list) {
            bw.write(l.getName());
            bw.newLine();
            newInteractionList(l);
            ArrayList<InteractionATC> alist = l.getInteractions();
            alist.sort(new ComparaATC());
            for (int i = 0; i < alist.size(); i++) {
                bw.write(alist.get(i).getAtc1() + ":" + alist.get(i).getAtc2() + ";" + alist.get(i).getCount());
                bw.newLine();
            }
        }
        bw.close();
    }

    /**
     *
     * @param list
     * @throws IOException
     */
    private static void mostfalsedescribedmedis_without_doubles(ArrayList<InteractionList> list) throws IOException {
        File f = new File("mostfalsedescribedmedis_without_doubles.txt");
        BufferedWriter bw = new BufferedWriter(new FileWriter(f));
        ArrayList<InteractionList> l1 = new ArrayList<InteractionList>(list.size());
        for (InteractionList l : list) {
            l1.add(new InteractionList(l));
        }

        for (InteractionList l : l1) {
            bw.write(l.getName());
            bw.newLine();

            HashMap<String, Long> map = new HashMap<String, Long>();

            newInteractionList(l);

            for (InteractionATC atc : l.getInteractions()) {
                if (map.containsKey(atc.getAtc1())) {
                    map.put(atc.getAtc1(), map.get(atc.getAtc1()) + atc.getCount_without_doubles());
                } else {
                    map.put(atc.getAtc1(), atc.getCount_without_doubles());
                }

                if (map.containsKey(atc.getAtc2())) {
                    map.put(atc.getAtc2(), map.get(atc.getAtc2()) + atc.getCount_without_doubles());
                } else {
                    map.put(atc.getAtc2(), atc.getCount_without_doubles());
                }
            }

            Map<String, Long> a = sortByValue(map);

            for (String str : a.keySet()) {

                bw.write(str + ";" + a.get(str));
                bw.newLine();
            }
        }

        bw.close();
    }

    /**
     *
     * @param list
     * @throws IOException
     */
    private static void mostfalsedescribedmedis_with_doubles(ArrayList<InteractionList> list) throws IOException {
        File f = new File("mostfalsedescribedmedis_with_doubles.txt");
        BufferedWriter bw = new BufferedWriter(new FileWriter(f));

        ArrayList<InteractionList> l1 = new ArrayList<InteractionList>(list.size() + 100);
        l1.addAll(list);

        for (InteractionList l : l1) {
            bw.write(l.getName());
            bw.newLine();

            HashMap<String, Long> map = new HashMap<String, Long>();

            newInteractionList(l);

            for (InteractionATC atc : l.getInteractions()) {
                if (map.containsKey(atc.getAtc1())) {
                    map.put(atc.getAtc1(), map.get(atc.getAtc1()) + atc.getCount());
                } else {
                    map.put(atc.getAtc1(), atc.getCount());
                }

                if (map.containsKey(atc.getAtc2())) {
                    map.put(atc.getAtc2(), map.get(atc.getAtc2()) + atc.getCount());
                } else {
                    map.put(atc.getAtc2(), atc.getCount());
                }
            }

            Map<String, Long> a = sortByValue(map);

            for (String str : a.keySet()) {

                bw.write(str + ";" + a.get(str));
                bw.newLine();
            }
        }

        bw.close();
    }

    /**
     *
     * @param list
     * @throws IOException
     */
    private static void mostfalsedescribedmedis_without_doubles_third_stage(ArrayList<InteractionList> list) throws IOException {
        File f = new File("mostfalsedescribedmedis_without_doubles_third_stage.txt");
        BufferedWriter bw = new BufferedWriter(new FileWriter(f));

        for (InteractionList l : list) {
            newInteractionList(l);
            bw.write(l.getName());
            bw.newLine();

            HashMap<String, Long> map = new HashMap<String, Long>();

            for (InteractionATC atc : l.getInteractions()) {
                try {
                    if (map.containsKey(atc.getAtc1().substring(0, 4))) {
                        map.put(atc.getAtc1().substring(0, 4), map.get(atc.getAtc1().substring(0, 4)) + atc.getCount_without_doubles());
                    } else {
                        map.put(atc.getAtc1().substring(0, 4), atc.getCount_without_doubles());
                    }
                    /**
                     * Wenn beide ATC-Codes der selben Gruppe angehören, wird
                     * nicht doppelt gezählt.
                     */
                    if (atc.atc1.substring(0, 4).equals(atc.atc2.substring(0, 4))) {
                        continue;
                    }

                    if (map.containsKey(atc.getAtc2().substring(0, 4))) {
                        map.put(atc.getAtc2().substring(0, 4), map.get(atc.getAtc2().substring(0, 4)) + atc.getCount_without_doubles());
                    } else {
                        map.put(atc.getAtc2().substring(0, 4), atc.getCount_without_doubles());
                    }
                } catch (StringIndexOutOfBoundsException ex) {
                    System.err.println("Fehler");
                }
            }

            Map<String, Long> a = sortByValue(map);

            for (String str : a.keySet()) {

                bw.write(str + ";" + a.get(str));
                bw.newLine();
            }
        }

        bw.close();
    }

    /**
     *
     * @param list
     * @throws IOException
     */
    private static void mostfalsedescribedmedis_with_doubles_third_stage(ArrayList<InteractionList> list) throws IOException {
        File f = new File("mostfalsedescribedmedis_with_doubles_third_stage.txt");
        BufferedWriter bw = new BufferedWriter(new FileWriter(f));

        for (InteractionList l : list) {
            bw.write(l.getName());
            bw.newLine();

            HashMap<String, Long> map = new HashMap<String, Long>();

            for (InteractionATC atc : l.getInteractions()) {
                try {
                    if (map.containsKey(atc.getAtc1().substring(0, 4))) {
                        map.put(atc.getAtc1().substring(0, 4), map.get(atc.getAtc1().substring(0, 4)) + atc.getCount_without_doubles());
                    } else {
                        map.put(atc.getAtc1().substring(0, 4), atc.getCount());
                    }

                    if (map.containsKey(atc.getAtc2().substring(0, 4))) {
                        map.put(atc.getAtc2().substring(0, 4), map.get(atc.getAtc2().substring(0, 4)) + atc.getCount_without_doubles());
                    } else {
                        map.put(atc.getAtc2().substring(0, 4), atc.getCount());
                    }
                } catch (StringIndexOutOfBoundsException ex) {
                }
            }

            Map<String, Long> a = sortByValue(map);

            for (String str : a.keySet()) {
                bw.write(str + ";" + a.get(str));
                bw.newLine();
            }
        }

        bw.close();
    }

    /**
     *
     * @param list
     * @throws IOException
     */
    private static void all_mostfalsedescribedmedis_without_doubles_third_stage(ArrayList<InteractionList> list) throws IOException {
        File f = new File("all_mostfalsedescribedmedis_without_doubles_third_stage.txt");
        BufferedWriter bw = new BufferedWriter(new FileWriter(f));
        HashMap<String, Long> map = new HashMap<String, Long>();

        for (InteractionList l : list) {

            for (InteractionATC atc : l.getInteractions()) {
                try {

                    if (map.containsKey(atc.getAtc1().substring(0, 4))) {
                        map.put(atc.getAtc1().substring(0, 4), map.get(atc.getAtc1().substring(0, 4)) + atc.getCount_without_doubles());
                    } else {
                        map.put(atc.getAtc1().substring(0, 4), atc.getCount_without_doubles());
                    }
                    /**
                     * Wenn beide ATC-Codes der selben Gruppe angehören, wird
                     * nicht doppelt gezählt.
                     */
                    if (atc.atc1.substring(0, 4).equals(atc.atc2.substring(0, 4))) {
                        continue;
                    }
                    if (map.containsKey(atc.getAtc2().substring(0, 4))) {
                        map.put(atc.getAtc2().substring(0, 4), map.get(atc.getAtc2().substring(0, 4)) + atc.getCount_without_doubles());
                    } else {
                        map.put(atc.getAtc2().substring(0, 4), atc.getCount_without_doubles());
                    }
                } catch (StringIndexOutOfBoundsException ex) {
                }
            }

        }
        Map<String, Long> a = sortByValue(map);

        for (String str : a.keySet()) {
            bw.write(str + ";" + a.get(str));
            bw.newLine();
        }
        bw.close();
    }

    /**
     *
     * @param list
     * @throws IOException
     */
    private static void all_mostInteractionATCs_withoutdoubles(ArrayList<InteractionList> list) throws IOException {
        File f = new File("all_mostInteractionATCs_without_doubles.txt");
        BufferedWriter bw = new BufferedWriter(new FileWriter(f));

        Set<InteractionATC> aset = new HashSet<InteractionATC>();
        ArrayList<InteractionATC> alist = new ArrayList<InteractionATC>();
        for (InteractionList l : list) {
            aset.addAll(l.getInteractions()); //doppelte werden aussortiert
        }
        alist.addAll(aset);
        alist.sort(new ComparaATC());
        InteractionList ilist = new InteractionList("all", alist);
        newInteractionList(ilist);

        for (int i = 0; i < ilist.getInteractions().size(); i++) {

            bw.write(alist.get(i).getAtc1() + ":" + alist.get(i).getAtc2() + ";" + alist.get(i).getCount_without_doubles());
            bw.newLine();

        }

        bw.close();
    }

    /**
     * Sortiert eine Map von groß nach klein
     *
     * @param <K>
     * @param <V>
     * @param map
     * @return
     */
    public static <K, V extends Comparable<? super V>> Map<K, V> sortByValue(Map<K, V> map) {
        List<Map.Entry<K, V>> list
                = new LinkedList<Map.Entry<K, V>>(map.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<K, V>>() {
            @Override
            public int compare(Map.Entry<K, V> o1, Map.Entry<K, V> o2) {
                return (o2.getValue()).compareTo(o1.getValue());
            }
        });

        Map<K, V> result = new LinkedHashMap<K, V>();
        for (Map.Entry<K, V> entry : list) {
            result.put(entry.getKey(), entry.getValue());
        }
        return result;
    }

    /**
     *
     * @param list
     * @throws IOException
     */
    private static void all_mostfalsedescribedmedis_without_doubles(ArrayList<InteractionList> list) throws IOException {
        File f = new File("all_mostfalsedescribedmedis_without_doubles.txt");
        BufferedWriter bw = new BufferedWriter(new FileWriter(f));
        HashMap<String, Long> map = new HashMap<String, Long>();

        ArrayList<InteractionList> l1 = new ArrayList<InteractionList>(list.size() + 1000);
        l1.addAll(list);

        for (InteractionList l : l1) {
            newInteractionList(l);

            for (InteractionATC atc : l.getInteractions()) {
                if (map.containsKey(atc.getAtc1())) {
                    map.put(atc.getAtc1(), map.get(atc.getAtc1()) + atc.getCount_without_doubles());
                } else {
                    map.put(atc.getAtc1(), atc.getCount_without_doubles());
                }

                if (map.containsKey(atc.getAtc2())) {
                    map.put(atc.getAtc2(), map.get(atc.getAtc2()) + atc.getCount_without_doubles());
                } else {
                    map.put(atc.getAtc2(), atc.getCount_without_doubles());
                }
            }

        }
        Map<String, Long> a = sortByValue(map);

        for (String str : a.keySet()) {

            bw.write(str + ";" + a.get(str));
            bw.newLine();
        }
        bw.close();
    }

    /**
     *
     * @param list
     * @throws IOException
     */
    private static void all_three_getInteractions_without_doubles(ArrayList<InteractionList> list) throws IOException {
        File f = new File("all_three_interactions_without_doubles.txt");
        BufferedWriter bw = new BufferedWriter(new FileWriter(f));
        Set<InteractionATC> set1 = new LinkedHashSet<InteractionATC>();
        Set<InteractionATC> set2 = new LinkedHashSet<InteractionATC>();
        Set<InteractionATC> set3 = new LinkedHashSet<InteractionATC>();

        ArrayList<InteractionATC> alist = new ArrayList<InteractionATC>();
        int a = 0;
        for (InteractionList l : list) {
            if (!l.getName().equals("interaction_french.csv") && !l.getName().equals("interaction_austria.csv") && !l.getName().equals("interaction_onc_high.csv")) {
                continue;
            }
            switch (a) {
                case 0:
                    set1.addAll(l.getInteractions());
                    a++;
                    break;
                case 1:
                    set2.addAll(l.getInteractions());
                    a++;
                    break;
                case 2:
                    set3.addAll(l.getInteractions());
                    a++;
                    break;
                default:
                    break;
            }

        }

        for (InteractionATC atc : set1) {
            if (set2.contains(atc) && set3.contains(atc)) {
                alist.add(atc);
            }
        }

        alist.sort(new ComparaATC());
        for (int i = 0; i < alist.size(); i++) {
            bw.write(alist.get(i).getAtc1() + ":" + alist.get(i).getAtc2() + ";" + alist.get(i).getCount_without_doubles());
            bw.newLine();
        }

        bw.close();
    }

    private static void onlyantidepressiva(ArrayList<InteractionList> list) throws IOException {
        File f = new File("onlyantidepressiva.txt");
        BufferedWriter bw = new BufferedWriter(new FileWriter(f));
        Set<InteractionATC> set1 = new LinkedHashSet<InteractionATC>();
        Set<InteractionATC> set2 = new LinkedHashSet<InteractionATC>();
        Set<InteractionATC> set3 = new LinkedHashSet<InteractionATC>();
        Set<InteractionATC> set4 = new LinkedHashSet<InteractionATC>();

        for (InteractionList l : list) {
            newInteractionList(l);
            if (!l.getName().equals("interaction_french.csv") && !l.getName().equals("interaction_austria.csv") && !l.getName().equals("interaction_onc_high.csv") && !l.getName().equals("interaction_austria_heavy.csv")) {
                continue;
            }
            if (l.getName().equals("interaction_french.csv")) {
                for (InteractionATC atc : l.getInteractions()) {
                    if (atc.atc1.contains("N06A") || atc.atc2.contains("N06A")) {
                        set1.add(atc);
                    }
                }
            } else if (l.getName().equals("interaction_austria.csv")) {
                for (InteractionATC atc : l.getInteractions()) {
                    if (atc.atc1.contains("N06A") || atc.atc2.contains("N06A")) {
                        set2.add(atc);
                    }
                }
            } else if (l.getName().equals("interaction_onc_high.csv")) {
                for (InteractionATC atc : l.getInteractions()) {
                    if (atc.atc1.contains("N06A") || atc.atc2.contains("N06A")) {
                        set3.add(atc);
                    }
                }
            } else if (l.getName().equals("interaction_austria_heavy.csv")) {
                for (InteractionATC atc : l.getInteractions()) {
                    if (atc.atc1.contains("N06A") || atc.atc2.contains("N06A")) {
                        set4.add(atc);
                    }
                }
            }
        }

        if (set1.isEmpty() && set2.isEmpty() && set3.isEmpty() && set4.isEmpty()) {
            return;
        }

        bw.write("interaction_french.csv");
        bw.newLine();
        for (InteractionATC atc : set1) {

            bw.write(atc.atc1 + ":" + atc.atc2 + ";" + atc.count_without_doubles);
            bw.newLine();
        }
        bw.write("interaction_austria.csv");
        bw.newLine();
        for (InteractionATC atc : set2) {

            bw.write(atc.atc1 + ":" + atc.atc2 + ";" + atc.count_without_doubles);
            bw.newLine();
        }
        bw.write("interaction_onc_high.csv");
        bw.newLine();
        for (InteractionATC atc : set3) {

            bw.write(atc.atc1 + ":" + atc.atc2 + ";" + atc.count_without_doubles);
            bw.newLine();
        }
        bw.write("interaction_austria_heavy.csv");
        bw.newLine();
        for (InteractionATC atc : set4) {

            bw.write(atc.atc1 + ":" + atc.atc2 + ";" + atc.count_without_doubles);
            bw.newLine();
        }

        bw.close();
    }

    public static void onlyantidepressivamedis(ArrayList<InteractionList> list) throws IOException {
        File f = new File("onlyantidepressivamedis.txt");
        BufferedWriter bw = new BufferedWriter(new FileWriter(f));
        HashMap<String, Long> map = new HashMap<String, Long>();

        ArrayList<InteractionList> l1 = new ArrayList<InteractionList>(list.size() + 100);
        l1.addAll(list);

        for (InteractionList l : l1) {

            newInteractionList(l);

            map.clear();
            if (!l.getName().equals("interaction_french.csv") && !l.getName().equals("interaction_austria.csv") && !l.getName().equals("interaction_onc_high.csv") && !l.getName().equals("interaction_austria_heavy.csv")) {
                continue;
            }

            for (InteractionATC atc : l.getInteractions()) {
                if (!atc.atc1.contains("N06A") && !atc.atc2.contains("N06A")) {
                    continue;
                }
                if (map.containsKey(atc.getAtc1())) {
                    map.put(atc.getAtc1(), map.get(atc.getAtc1()) + atc.getCount_without_doubles());
                } else {
                    map.put(atc.getAtc1(), atc.getCount_without_doubles());
                }

                if (map.containsKey(atc.getAtc2())) {
                    map.put(atc.getAtc2(), map.get(atc.getAtc2()) + atc.getCount_without_doubles());
                } else {
                    map.put(atc.getAtc2(), atc.getCount_without_doubles());
                }
            }
            Map<String, Long> a = sortByValue(map);

            if (l.getName().equals("interaction_french.csv")) {
                bw.write("interaction_french.csv");
                bw.newLine();
            } else if (l.getName().equals("interaction_austria.csv")) {
                bw.write("interaction_austria.csv");
                bw.newLine();
            } else if (l.getName().equals("interaction_onc_high.csv")) {
                bw.write("interaction_onc_high.csv");
                bw.newLine();
            } else if (l.getName().equals("interaction_austria_heavy.csv")) {
                bw.write("interaction_austria_heavy.csv");
                bw.newLine();
            }

            for (String str : a.keySet()) {
                if (str.contains("N06A")) {
                    bw.write(str + ";" + a.get(str));
                    bw.newLine();
                }
            }

        }
        bw.close();
    }

    /**
     * neue Liste, welche die ATCs kürzer als 7 in die Einzelnen ATC-Codes
     * aufteilt
     *
     * @param l
     */
    public static void newInteractionList(InteractionList l) {
        ArrayList<InteractionATC> deletelist = new ArrayList<InteractionATC>();
        ArrayList<InteractionATC> addlist = new ArrayList<InteractionATC>();

        for (InteractionATC atc : l.getInteractions()) {
            int i = 0;
            int j = 0;
            if (atc.atcgeneral) {
                if (!(atc.atcs == null)) {
                    if (!atc.atcs.isEmpty()) {
                        for (InteractionATC a : atc.atcs) {
                            i += a.count;
                            j += a.count_without_doubles;
                            addlist.add(a);
                        }
                        if (atc.count != i) {
                            if (atc.count_without_doubles != j) {
                                System.err.println("Nicht gleich!");
                                throw new RuntimeException();
                            }
                        }
                        deletelist.add(atc);

                    } else {
                        deletelist.add(atc);
                    }
                }
            }
        }
        l.getInteractions().removeAll(deletelist);
        l.interactions.addAll(addlist);
    }

}
