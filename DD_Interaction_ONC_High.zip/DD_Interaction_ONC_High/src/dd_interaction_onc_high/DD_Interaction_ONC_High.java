package dd_interaction_onc_high;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Erzeugt aus den zwei XML-Dateien die passende CSV-Datei
 * @author Wolfgang Kuch
 */
public class DD_Interaction_ONC_High {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ParserConfigurationException, IOException, SAXException {
        ArrayList<Drug> drugs = new ArrayList<>();
        ArrayList<InteractionDrugs> interactions = new ArrayList<>();

        File atc_file = new File("ONC High Priority ATC.xml");

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(atc_file);

        doc.getDocumentElement().normalize();

        NodeList nl = doc.getElementsByTagName("DRUG");

        for (int i = 0; i < nl.getLength(); i++) {
            Drug d = new Drug(nl.item(i).getAttributes().getNamedItem("med").getNodeValue());
            if (drugs.contains(d)) {
                continue;
            }

            String[] atcs = nl.item(i).getChildNodes().item(0).getNodeValue().split("\\R");

            for (String atc : atcs) {
                d.addAtc(atc);
            }
            
            drugs.add(d);
        }

        /**
         * Interaktionen erstellen
         */
        File interact_file = new File("ONC High Priority.xml");

        factory = DocumentBuilderFactory.newInstance();
        builder = factory.newDocumentBuilder();
        doc = builder.parse(interact_file);

        doc.getDocumentElement().normalize();

        nl = doc.getElementsByTagName("INTERACTION");

        for (int i = 0; i < nl.getLength(); i++) {
            String s1 = nl.item(i).getChildNodes().item(1).getChildNodes().item(0).getNodeValue();
            String[] atcs = s1.split("\\R");
            int index;
            
            for(String atc1 : atcs) {
                if(atc1.equals("")) {
                    continue;
                }
                
                Drug d1 = new Drug(atc1);
                index = drugs.indexOf(d1);
                if(index == -1) {
                    continue;
                }
                
                d1 = drugs.get(index);
                
                String s2 = nl.item(i).getChildNodes().item(3).getChildNodes().item(0).getNodeValue();
                atcs = s2.split("\\R");
                
                for(String atc2 : atcs) {
                    if(atc2.equals("")) {
                        continue;
                    }
                    
                    Drug d2 = new Drug(atc2);
                    index = drugs.indexOf(d2);
                    if(index == -1) {
                        continue;
                    }
                    
                    d2 = drugs.get(index);
                    
                    /**
                     * InteractionDrugs erstellen und in ArrayList Speichern
                     */
                    
                    interactions.add(new InteractionDrugs(d1, d2));
                }
            }    
        }
        
        /**
         * interaction_onc_high.csv erstellen
         */
        
        File interactioncsv = new File("interaction_onc_high.csv");
        PrintWriter pw = new PrintWriter(new FileWriter(interactioncsv));
        
        StringBuilder interaction;
        
        for(InteractionDrugs interact : interactions) {
            for(String atc1 : interact.getDrug1().getAtc()) {
                interaction = new StringBuilder(15);
                interaction.append(atc1);
                for(String atc2 : interact.getDrug2().getAtc()) {
                    interaction.append(";");
                    interaction.append(atc2);
                    pw.println(interaction.toString());
                    interaction.delete(interaction.indexOf(";"), interaction.length());
                }
            }
        }
        pw.close();
    }
}
