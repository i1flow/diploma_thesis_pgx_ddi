package dd_interaction_onc_high;

import java.util.*;

/**
 *
 * @author Wolfi
 */
public class Drug {
    private String drugname;
    private final ArrayList<String> atc = new ArrayList<>();

    public Drug(String drugname) {
        this.drugname = drugname;
    }

    public Drug() {
    }

    public void addAtc(String atc_code) {
        if(!atc_code.equals("")) {
            this.atc.add(atc_code);
        }
    }

    public ArrayList<String> getAtc() {
        return this.atc;
    }

    public String getDrugname() {
        return drugname;
    }

    public void setDrugname(String drugname) {
        this.drugname = drugname;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 11 * hash + Objects.hashCode(this.drugname);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Drug other = (Drug) obj;
        if (!Objects.equals(this.drugname, other.drugname)) {
            return false;
        }
        return true;
    }
    
    

}
