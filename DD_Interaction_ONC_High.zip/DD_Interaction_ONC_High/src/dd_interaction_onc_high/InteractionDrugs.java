package dd_interaction_onc_high;

import java.io.Serializable;

/**
 *
 * @author Wolfi
 */
public class InteractionDrugs implements Serializable{
    private Drug drug1;
    private Drug drug2;

    public InteractionDrugs(Drug drug1, Drug drug2) {
        this.drug1 = drug1;
        this.drug2 = drug2;
    }

    
    public Drug getDrug1() {
        return drug1;
    }

    public void setDrug1(Drug drug1) {
        this.drug1 = drug1;
    }

    public Drug getDrug2() {
        return drug2;
    }

    public void setDrug2(Drug drug2) {
        this.drug2 = drug2;
    }
    
    
}
