package dd_interaction_french;

import java.io.*;
import java.util.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

/**
 * Erzeugt aus den zwei XML-Dateien der franz. Interaktionsliste eine CSV-Datei
 * mit den ATC-Codes
 *
 * @author Wolfgang Kuch
 */
public class DD_Interaction_french {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     * @throws org.xml.sax.SAXException
     * @throws javax.xml.parsers.ParserConfigurationException
     */
    public static void main(String[] args) throws FileNotFoundException, IOException, SAXException, ParserConfigurationException {
        ArrayList<Drug> v = new ArrayList<Drug>();
        File f = new File("all_eng_groups2015.xml");
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(f);

        doc.getDocumentElement().normalize();

        NodeList nList = doc.getElementsByTagName("CLASS");

        for (int i = 0; i < nList.getLength(); i++) {
            Drug d = new Drug();
            String drugclass = nList.item(i).getAttributes().getNamedItem("name").toString();
            d.setDrugclass(drugclass);

            for (int j = 3; j < nList.item(i).getChildNodes().getLength(); j += 2) {
                String drug = nList.item(i).getChildNodes().item(j).getAttributes().getNamedItem("name").toString();
                d.setDrugname(drug);

                try {
                    for (int k = 1; k < nList.item(i).getChildNodes().item(j).getChildNodes().getLength(); k += 2) {
                        String atc = nList.item(i).getChildNodes().item(j).getChildNodes().item(k).getAttributes().getNamedItem("code").toString();
                        d.addAtc(atc);
                    }
                } catch (java.lang.NullPointerException ex) {

                }
            }

            v.add(d);
        }

        f = new File("all_eng_tables2015.xml");
        factory = DocumentBuilderFactory.newInstance();
        builder = factory.newDocumentBuilder();
        doc = builder.parse(f);

        doc.getDocumentElement().normalize();

        nList = doc.getElementsByTagName("INTERACTION");

        ArrayList interactiondrugs = new ArrayList();

        for (int i = 0; i < nList.getLength(); i++) {
            try {
                //Drug1
                String drugname1 = nList.item(i).getChildNodes().item(3).getChildNodes().item(1).getAttributes().getNamedItem("name").toString();
                if ("DRUG".equalsIgnoreCase(nList.item(i).getChildNodes().item(3).getChildNodes().item(1).getNodeName())) {
                    Drug d1 = getDrugfromArray(v, drugname1);
                    if (d1 == null) {
                        continue;
                    }
                    //Drug2
                    String drugname2 = nList.item(i).getChildNodes().item(5).getChildNodes().item(1).getAttributes().getNamedItem("name").toString();
                    if ("DRUG".equalsIgnoreCase(nList.item(i).getChildNodes().item(5).getChildNodes().item(1).getNodeName())) {
                        Drug d2 = getDrugfromArray(v, drugname2);
                        if (d2 == null) {
                            continue;
                        }
                        InteractionDrugs interact = new InteractionDrugs(d1, d2);
                        interactiondrugs.add(interact);
                    } else {
                        String cl = nList.item(i).getChildNodes().item(5).getChildNodes().item(1).getAttributes().getNamedItem("name").toString();
                        ArrayList l = getDrugArrayfromArray(v, cl);

                        for (Iterator it = l.iterator(); it.hasNext();) {
                            Drug d2 = (Drug) it.next();

                            InteractionDrugs interact = new InteractionDrugs(d1, d2);
                            interactiondrugs.add(interact);

                        }
                    }

                } else {
                    String drugname2 = nList.item(i).getChildNodes().item(5).getChildNodes().item(1).getAttributes().getNamedItem("name").toString();

                    if ("DRUG".equalsIgnoreCase(nList.item(i).getChildNodes().item(5).getChildNodes().item(1).getNodeName())) {
                        Drug d2 = getDrugfromArray(v, drugname2);
                        if (d2 == null) {
                            continue;
                        }

                        String cl = nList.item(i).getChildNodes().item(3).getChildNodes().item(1).getAttributes().getNamedItem("name").toString();
                        ArrayList l = getDrugArrayfromArray(v, cl);

                        for (Iterator it = l.iterator(); it.hasNext();) {
                            Drug d1 = (Drug) it.next();

                            InteractionDrugs interact = new InteractionDrugs(d1, d2);
                            interactiondrugs.add(interact);

                        }
                    } else {
                        String cl1 = nList.item(i).getChildNodes().item(3).getChildNodes().item(1).getAttributes().getNamedItem("name").toString();
                        ArrayList l1 = getDrugArrayfromArray(v, cl1);

                        for (Iterator it = l1.iterator(); it.hasNext();) {
                            Drug d1 = (Drug) it.next();

                            String cl2 = nList.item(i).getChildNodes().item(5).getChildNodes().item(1).getAttributes().getNamedItem("name").toString();
                            ArrayList l2 = getDrugArrayfromArray(v, cl2);

                            for (Iterator it2 = l2.iterator(); it2.hasNext();) {
                                Drug d2 = (Drug) it2.next();

                                InteractionDrugs interact = new InteractionDrugs(d1, d2);
                                interactiondrugs.add(interact);
                            }
                        }
                    }

                }

            } catch (java.lang.NullPointerException ex) {
            }
        }

        FileWriter out = new FileWriter("interaction_french.csv");
        BufferedWriter bw = new BufferedWriter(out);

        for (Iterator it = interactiondrugs.iterator(); it.hasNext();) {
            InteractionDrugs dr = (InteractionDrugs) it.next();
            String atc1 = null;
            String atc2 = null;

            if (dr.getDrug1().getAtc().isEmpty()) {
                continue;
            } else {
                for (Iterator itatc1 = dr.getDrug1().getAtc().iterator(); itatc1.hasNext();) {
                    atc1 = (String) itatc1.next();

                    if (dr.getDrug2().getAtc().isEmpty()) {
                        continue;
                    } else {
                        for (Iterator itatc2 = dr.getDrug2().getAtc().iterator(); itatc2.hasNext();) {
                            atc2 = (String) itatc2.next();
                            bw.write(cutStringforATC(atc1) + ";" + cutStringforATC(atc2));
                            bw.newLine();
                        }
                    }
                }
            }

        }

        bw.close();

    }

    /**
     * 
     * @param list
     * @param drugname
     * @return 
     */
    private static Drug getDrugfromArray(ArrayList list, String drugname) {

        for (Iterator it = list.iterator(); it.hasNext();) {
            Drug d = (Drug) it.next();
            if (d.getDrugname().equalsIgnoreCase(drugname)) {
                return d;
            }
        }

        return null;
    }

    /**
     * 
     * @param list
     * @param drugclass
     * @return 
     */
    private static ArrayList getDrugArrayfromArray(ArrayList list, String drugclass) {
        ArrayList drug = new ArrayList();

        for (Iterator it = list.iterator(); it.hasNext();) {
            Drug d = (Drug) it.next();
            if (d.getDrugclass().equalsIgnoreCase(drugclass)) {
                drug.add(d);
            }
        }

        return drug;
    }

    /**
     * 
     * @param atc
     * @return 
     */
    private static String cutStringforATC(String atc) {
        if (atc != null || !atc.equals("")) {
            atc = atc.substring(6);
            atc = atc.substring(0, atc.length() - 1);
            if (atc.length() > 7) {
                atc = atc.substring(0, 7);
            }
        }

        return atc;
    }
}
