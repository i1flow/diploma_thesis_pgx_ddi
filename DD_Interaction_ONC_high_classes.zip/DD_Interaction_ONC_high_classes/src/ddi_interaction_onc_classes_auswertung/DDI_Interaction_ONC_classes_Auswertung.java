package ddi_interaction_onc_classes_auswertung;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author Wolfgang Kuch
 */
public class DDI_Interaction_ONC_classes_Auswertung {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException {
        int klasse = 0;
        ArrayList<Drug> drugs = new ArrayList<>();
        ArrayList<InteractionDrugs> interactions = new ArrayList<>();

        File atc_file = new File("/Users/Wolfi/Desktop/Diplomarbeit/DDI/InteraktionsListen/ONC_High_priority-List/ONC High Priority ATC.xml");

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(atc_file);

        doc.getDocumentElement().normalize();

        NodeList nl = doc.getElementsByTagName("DRUG");

        for (int i = 0; i < nl.getLength(); i++) {
            Drug d = new Drug(nl.item(i).getAttributes().getNamedItem("med").getNodeValue());
            if (drugs.contains(d)) {
                continue;
            }

            String[] atcs = nl.item(i).getChildNodes().item(0).getNodeValue().split("\n");

            for (String atc : atcs) {
                d.addAtc(atc);
            }

            drugs.add(d);
        }

        File interact_file = new File("/Users/Wolfi/Desktop/Diplomarbeit/DDI/InteraktionsListen/ONC_High_priority-List/ONC High Priority.xml");

        factory = DocumentBuilderFactory.newInstance();
        builder = factory.newDocumentBuilder();
        doc = builder.parse(interact_file);

        doc.getDocumentElement().normalize();

        nl = doc.getElementsByTagName("INTERACTION");

        for (int i = 0; i < nl.getLength(); i++) {
            String s1 = nl.item(i).getChildNodes().item(1).getChildNodes().item(0).getNodeValue();
            String[] atcs = s1.split("\n");
            int index;

            for (String atc1 : atcs) {
                Drug d1 = new Drug(atc1);
                index = drugs.indexOf(d1);
                if (index == -1) {
                    continue;
                }

                d1 = drugs.get(index);

                String s2 = nl.item(i).getChildNodes().item(3).getChildNodes().item(0).getNodeValue();
                atcs = s2.split("\n");

                for (String atc2 : atcs) {
                    Drug d2 = new Drug(atc2);
                    index = drugs.indexOf(d2);
                    if (index == -1) {
                        continue;
                    }

                    d2 = drugs.get(index);

                    /**
                     * InteractionDrugs erstellen und in ArrayList Speichern
                     */
                    interactions.add(new InteractionDrugs(d1, d2));
                }
            }

            /**
             * interaction_onc_high.csv erstellen
             */
            if (interactions.size() == 0) {
                klasse++;
                continue;
            }
            File interactioncsv = new File("interaction_onc_high" + klasse++ + ".csv");
            PrintWriter pw = new PrintWriter(new FileWriter(interactioncsv));

            StringBuilder interaction;

            for (InteractionDrugs interact : interactions) {
                for (String atc1 : interact.getDrug1().getAtc()) {
                    interaction = new StringBuilder(15);
                    interaction.append(atc1);
                    for (String atc2 : interact.getDrug2().getAtc()) {
                        interaction.append(";");
                        interaction.append(atc2);
                        pw.println(interaction.toString());
                        interaction.delete(interaction.indexOf(";"), interaction.length());
                    }
                }
            }
            pw.close();

            interactions.clear();
        }
    }

}
